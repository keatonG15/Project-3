#include <iostream>
#include "userInfo.h"
#include <vector>
#include <fstream>
#include <string>
using namespace std;
 
userInfo::userInfo(){
   userName = "";
   frustration = 0;
   infestation = 0;
   viruses = 0;
   skiMaintenance = 100;
   jerriesDefeated = 0;
   moves = 0;
   moveOn = 0;
 
 
} // default constructor
userInfo::userInfo(string nameUser, int frust, int infes, int virus, int skiMain, int jerriesDef, int move){
 
       userName = nameUser;
       frustration = frust;
       infestation = infes;
       viruses = virus;
       skiMaintenance = skiMain;
       jerriesDefeated = jerriesDef;
       moves = move;
       
      
 //
}
 
   string userInfo::getUserName(){
       return userName;
   }
   void userInfo::setUserName(string n){
       userName = n;
 
   }
   int userInfo::getFrustration(){
       
       return frustration;
   }
   void userInfo::setFrustration(int f){
       frustration = f;
   }
    int userInfo::getMoves(){
        return moves;
    }
   void userInfo::setMoves(int move){
       moves = move;
   }
   int userInfo::getInfestation(){
       return infestation;
   }
   void userInfo::setInfestation(int s){
       infestation = s;
   }
   int userInfo::getViruses(){
       return viruses;
   }
   void userInfo::setViruses(int v){
       viruses = v;
   }
   int userInfo::getSkiMaintenance(){
       return skiMaintenance;
   }
   void userInfo::setskiMaintenance(int sM){
       skiMaintenance = sM;
   }
   int userInfo::getJerriesDefeated(){
       return jerriesDefeated;
 
   }
   void userInfo:: setJerriesDefeated(int jD){
       jerriesDefeated = jD;
 
   }
   void userInfo::displayUser(){
       string name;
       cout << endl << "Whaaaat up my guy! So stoked to hear you're joining the squad! Gonna shred some gnarly terrain this year!\nWhat's your name again amigo?" << endl;
       getline(cin, name);
        setUserName(name);
       cout << name << " thats right bro! Anyways, welcome to Squaw Valley, home of the gnarliest double sets in the world!" << endl;
       cout << "I heard there was some trouble over by the fingers, some Jerries got tangled up in the chutes.\n" << name << " why dont you go over there and clear them out so we can rip it later?" << endl;
       cout << "I'll run you over to the store so you can stock up and be prepared for anything! You never know what's gonna happen in the great outdoors at any time!" << endl;
       cout << "===========" << endl;
       displayStats();
      
      
   }
   void userInfo::displayStats(){
       cout << "Frustration: " << getFrustration() << endl;
       cout << "Infestation: " << getInfestation() << endl;
       cout << "Viruses: " << getViruses() << endl;
       cout << "Ski Maintenance: " << getSkiMaintenance() << endl;
       cout << "Jerries Defeated: " << getJerriesDefeated() << endl;
   }
 int userInfo::getMoveOn(){
     return moveOn;
 }
  void userInfo::setMoveOn(int value){
      moveOn = value;
  }
 
int userInfo::split(string input, char del, string names[], double scores[], int piecesLength){
  //holder holds the strings that appear before the delimeter
    string holder = "";
    //location helps us assign the position of piece, delOccurences will be checked to see if/how many delimeters there are 
    int location = piecesLength, delOccurences = -1;
    //adds delimeter to end of string so that we know when to stop... delOccurences is -1 becasue once we add this it goes to 0
    
//cant run an empty string
    if(input.length() <= 1) return 0;

//runs as many times as input is long
    for(unsigned int i = 0; i < input.length(); i++){
      //if the location is the delimeter, set piece[location] to the holder string, clear holder string, reassign location for next placement, and delOccurences.
       if(input[i] == ','){
          names[location] = input.substr(0,i);
         // cout << input.substr(i+1, input.length()-i) << endl;
          scores[location] = stod(input.substr(i+1, input.length()-i));
          holder = "";
          location++;
          delOccurences++;
          //if not keep building up holder
       }else{
         holder += input[i];

       }
            
    }
   // cout << "checkDel: " << delOccurences << endl; 
   //delOccurences = how many strings so if there are more strings then places to put them return -1
    if(delOccurences > piecesLength) return -1;

//if there are no occurences, return 1
    if(delOccurences == 0){
      names[0] = input;
      return 1;
    } 
   //cout all the pieces
 
    return piecesLength;
}


void userInfo::makeLeaderboard(){
   if(getSkiMaintenance() > 0 && getFrustration() < 100 && getInfestation() < 100){
    ofstream outFile;
    outFile.open("leaderboard.txt", ios_base::app);
    double score = ((double)getJerriesDefeated()/ getMoves()) * 100;
    outFile << getUserName() << "," << score <<  endl;
        outFile.close();
   }
    string line;
    string listNames[100];
    double listScores[100];

    


    ifstream inFile;
    inFile.open("leaderboard.txt");
    int pos = 1;
    
    while(getline(inFile, line) && line.length() > 0){
       split(line, ',', listNames, listScores, pos);
      // cout <<listNames[pos] << ": " << listScores[pos] << endl;
       pos++;

    }  
    vector<double>scoreVector;
    vector<string>nameVector;
    for(int d = 0; d < pos-1; d++){
       // cout << listNames[d] << ": " << listScores[d] << endl;
        scoreVector.push_back(listScores[d+1]);
        nameVector.push_back(listNames[d+1]);
        //cout << nameVector.at(d) << ": " << scoreVector.at(d) << endl;
        //cout << scoreVector.at(d-1) << endl;
    }
    vector<double> sorted;
    vector<string> sortedNames;
    double maxHolder = scoreVector.at(0);
    int maxPos = 0;
    string maxName = "";
  cout << "=====Leaderboard=====" << endl;
    for(int i = 0; i < 5; i++){
        for(int x = 0; x < scoreVector.size(); x++){
            if(scoreVector.at(x) >= maxHolder){
                 maxHolder = scoreVector.at(x);
                 maxPos = x;
                 maxName = nameVector.at(x);
            }
        }
     
sorted.push_back(maxHolder);
sortedNames.push_back(maxName);
   cout <<i+1 << ". "<< sortedNames.at(i) << ": " << sorted.at(i) << endl;
scoreVector.erase(scoreVector.begin()+maxPos);
nameVector.erase(nameVector.begin()+maxPos);
maxHolder = scoreVector.at(0);
maxPos = 0;
    }
    inFile.close();

  
    








    
abort();
}



