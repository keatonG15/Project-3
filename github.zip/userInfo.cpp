#include <iostream>
#include "userInfo.h"
#include <vector>
using namespace std;
 
userInfo::userInfo(){
   userName = "";
   frustration = 0;
   infestation = 0;
   viruses = 0;
   skiMaintenance = 100;
   jerriesDefeated = 0;
   moves = 0;
   moveOn = 0;
 
 
} // default constructor
userInfo::userInfo(string nameUser, int frust, int infes, int virus, int skiMain, int jerriesDef, int move){
 
       userName = nameUser;
       frustration = frust;
       infestation = infes;
       viruses = virus;
       skiMaintenance = skiMain;
       jerriesDefeated = jerriesDef;
       moves = move;
       
      
 //
}
 
   string userInfo::getUserName(){
       return userName;
   }
   void userInfo::setUserName(string n){
       userName = n;
 
   }
   int userInfo::getFrustration(){
       if(frustration >=100){
           cout << "Game Over" << endl;
           return 100;
           abort();
       }
       return frustration;
   }
   void userInfo::setFrustration(int f){
       frustration = f;
   }
    int userInfo::getMoves(){
        return moves;
    }
   void userInfo::setMoves(int move){
       moves = move;
   }
   int userInfo::getInfestation(){
       return infestation;
   }
   void userInfo::setInfestation(int s){
       infestation = s;
   }
   int userInfo::getViruses(){
       return viruses;
   }
   void userInfo::setViruses(int v){
       viruses = v;
   }
   int userInfo::getSkiMaintenance(){
       return skiMaintenance;
   }
   void userInfo::setskiMaintenance(int sM){
       skiMaintenance = sM;
   }
   int userInfo::getJerriesDefeated(){
       return jerriesDefeated;
 
   }
   void userInfo:: setJerriesDefeated(int jD){
       jerriesDefeated = jD;
 
   }
   void userInfo::displayUser(){
       string name;
       cout << "enter ur name" << endl;
       cin >> name;
       setUserName(name);
       cout << "Hello " << getUserName() << endl;
       cout << "===========" << endl;
       displayStats();
      
      
   }
   void userInfo::displayStats(){
       cout << "Frustration: " << getFrustration() << endl;
       cout << "Infestation: " << getInfestation() << endl;
       cout << "Viruses: " << getViruses() << endl;
       cout << "Ski Maintenance: " << getSkiMaintenance() << endl;
       cout << "Jerries Defeated: " << getJerriesDefeated() << endl;
   }
 int userInfo::getMoveOn(){
     return moveOn;
 }
  void userInfo::setMoveOn(int value){
      moveOn = value;
  }
 

