------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ P7.h P7.cpp Jerry.h Jerry.cpp Map.h Map.cpp NPC.h NPC.cpp userInfo.h userInfo.cpp testDriver.cpp
Run: ./a.out
------------------------
DEPENDENCIES
------------------------
All .h classes must be in the same directory as the cpp files in 
order to compile.
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Fall 2021 Project 3
Author: Alex Norby and Keaton Glassman
Recitation: 212 - Sannidhi , 213 - Jerry Gammie
Date: December 2, 2021
------------------------
ABOUT THIS PROJECT
------------------------

User Defined Classes: Jerry.h NPC.h userInfo.h P7.h
Every class has 4+ data members, multiple classes include vectors
Every class has getters/setters
You can find 6+ if/else statements in testDriver.cpp
You can find 6+ loops in testDriver.cpp
Nested For loop in makeLeaderboard() in userInfo.cpp
Multiple nested loops within overarching while loop in testDriver.cpp (while(mountainNumber <= 5) line 86)
Read and Write files in makeLeaderboard() in userInfo.cpp
2D map displayed in game and with Map class
Interacts with getting name, answering riddles, and taking in decisions
Maintenance, viruses, frustration, and infestation is displayed as stats in inventory and with misfortunes 
Multiple menu options found in P7.cpp
When misfortunes occur, random events will occur i.e taking random piece(s) of equipment
In repairFrustration() the chances of your movie being the most satisfying is a 10% chance
Sorting algorithm in makeLeaderboard() sets the highest scores in order

