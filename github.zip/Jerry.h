// CSCI 1300 Fall 2021
// Authors: Alex Norby and Keaton Glassman
// Recitation 212 and 213
// Project 3 -- Jerry.h

#include <iostream>
#include <vector>
#include <string>
using namespace std;
 #ifndef JERRY_H //Helps call a class
 #define JERRY_H // Defines the class
 
class P7;
class Jerry{
 
   public:
   Jerry(); // default constructor
   Jerry(vector<string>name,  int pL, int r1, int r2, int mountNum, int swagNum); // parameterized constructor
 
   int displayJerry();
   bool getResults(); // results if you won or not. If over 0 then you win
   void setFight(int pL, int r1, int r2, int mountNum, int swagNum); // where we put equation for if you won or not

   int getMountain();//gets mountain number
   void setMountain(int value);//sets mountain number

   int getSwagNum();//gets swag number
   void setSwagNum(int num);//sets swag number

   int getPoleLvl();//gets pole lvl
   void setPoleLvl(int lvl);//sets pole lvl

   string getJerryName(int index);//gets jerry name
   void setNames(int mountNum, int remove);//sets names with mountain number and jerries defeated
   //needs to be publicly accessed by other classes
 int mountainNumber;
 
   private:
 //private to user 
   vector<string>jNames;
   bool isDefeated;
   int poleLevel;
   int randNumber1;
   int randNumber2;
   int swag;

};
#endif

