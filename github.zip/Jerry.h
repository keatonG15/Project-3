#include <iostream>
#include <vector>
#include <string>
using namespace std;
 #ifndef JERRY_H //Helps call a class
 #define JERRY_H // Defines the class
 
class P7;
class Jerry{
 
   public:
   Jerry(); // default constructor
   Jerry(vector<string>name,  int pL, int r1, int r2, int mountNum, int swagNum); // parameterized constructor
 
   int displayJerry();
   bool getResults(); // results if you won or not. If over 0 then you win
   void setFight(int pL, int r1, int r2, int mountNum, int swagNum); // where we put equation for if you won or not

   int getMountain();
   void setMountain(int value);

   int getSwagNum();
   void setSwagNum(int num);

   int getPoleLvl();
   void setPoleLvl(int lvl);

   string getJerryName(int index);
   void setNames(int mountNum, int remove);
 int mountainNumber;
 
   private:
 
   vector<string>jNames;
   bool isDefeated;
   int poleLevel;
   int randNumber1;
   int randNumber2;
   int swag;

};
#endif

