#ifndef USERINFO_H
#define USERINFO_H
#include <string>
#include <vector>
#include <iostream>
using namespace std;
 
 
class userInfo{
   private:
 
   string userName; 
  
 
 
 //
   public:
 
   userInfo(); // default constructor
   userInfo(string nameUser, int frust, int infes, int virus, int skiMain, int jerriesDef, int move);
 
   string getUserName();
   void setUserName(string n);
   int getFrustration();
   void setFrustration(int f);
   int getInfestation();
   void setMoves(int move); 
   int getMoves();
   void setInfestation(int s);
   int getViruses();
   void setViruses(int v);
   int getSkiMaintenance();
   void setskiMaintenance(int sM);
   int getJerriesDefeated();
   void setJerriesDefeated(int jD);
   void displayUser();
   void displayStats();
  int getMoveOn();
  void setMoveOn(int value);
  
 
  int frustration;
   int infestation;
   int viruses;
   int skiMaintenance;
   int jerriesDefeated;
   int moves;
   int moveOn;
   
 
 
 
 
};
 
#endif

