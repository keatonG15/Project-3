// CSCI 1300 Fall 2021
// Authors: Alex Norby and Keaton Glassman
// Recitation 212 and 213
// Project 3 -- userInfo.h

#ifndef USERINFO_H
#define USERINFO_H
#include <string>
#include <vector>
#include <iostream>
using namespace std;
 
 
class userInfo{
   private:
 // only thing that needs to be private
   string userName; 
  
 
 
 // since the class has mostly all stats about the user the variables need to be public so we can access them
   public:


   userInfo(); // default constructor
   userInfo(string nameUser, int frust, int infes, int virus, int skiMain, int jerriesDef, int move); // parameterized constructor
 // all getters and setters
   string getUserName();
   void setUserName(string n);
   int getFrustration();
   void setFrustration(int f);
   int getInfestation();
   void setMoves(int move); 
   int getMoves();
   void setInfestation(int s);
   int getViruses();
   void setViruses(int v);
   int getSkiMaintenance();
   void setskiMaintenance(int sM);
   int getJerriesDefeated();
   void setJerriesDefeated(int jD);
   void displayUser();
   void displayStats(); // this displays all the stats of the user so they can see what they can afford, ect.
  int getMoveOn(); // keeps tract of jerries defeated per mountain not in general
  void setMoveOn(int value); // sets above
  int split(string input, char del, string names[], double scores[], int piecesLength); 
  void makeLeaderboard(); // makes leaderboard, writes to the file of top 5 scores and stores it.
  
 // public, makes sure it is accessible
  int frustration;
   int infestation;
   int viruses;
   int skiMaintenance;
   int jerriesDefeated;
   int moves;
   int moveOn;
   
 
 
 
 
};
 
#endif

