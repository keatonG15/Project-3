// CSCI 1300 Fall 2021
// Authors: Alex Norby and Keaton Glassman
// Recitation 212 and 213
// Project 3 -- NPC.cpp

using namespace std;
#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include "NPC.h"

NPC::NPC(){
    //holds puzzles and NPC names in a vector
    srand(time(NULL));
    ifstream inFile;
    inFile.open("puzzles.txt");
    string line;
string npcNames[6] = {"Jackson", "Tommy", "Kelston", "Renner", "Alex Hall", "Tanner Hall"};
for(int i = 0; i < 6; i++){
    names.push_back(npcNames[i]);
    //cout << names.at(i) << endl;
}
int x = 0;
while(getline(inFile,line) && line.length() > 0){
    puzzles.push_back(line);
}
inFile.close();
inFile.open("answers.txt");
int hold;
while(inFile >> hold){
    answers.push_back(hold);
}

randRelationship = rand()%3+1;
isJerry = false;

//this is where we create a file of puzzles and answers and fill arrays with them

}

NPC::NPC(vector<string>name, vector<string>puzzle, int relationship, bool jerry){
    //same as default but parameterized
for(int i = 0; i < name.size(); i++){
    names.push_back(name[i]);
}
for(int x = name.size(); x < names.size(); x++){
    names.push_back("John");
}
randRelationship = relationship;
isJerry = jerry;
}

int NPC::displayNPC(){
  
srand(time(NULL));
//gets a random name 
 randName = rand()%names.size()-1;
if(randName < 0) randName = 4;
string userAnswer;
//displays NPC interaction
cout << "You ran into " << getNPCName(randName) << ". Would you like to:\n1.Answer a riddle\n2.Take Chances" << endl;
cin >> userAnswer;
//answer a riddle
if(userAnswer == "1"){
    string in;
    int input = 0;
int randPuzzle = rand()%10;
//gets a random puzzle 
cout << getPuzzle(randPuzzle) << endl;
//cout << "Answer: " << getAnswer(randPuzzle) << endl;
cin >> in;
//converts input to int so we can use it as an index
if(in.length() == 1 && in[0] > 48 && in[0] < 53){
    input = stoi(in);
 
}

if(input == getAnswer(randPuzzle)){
    cout << "Correct!"<<endl;
    return 1;
    
    //0 = 50 beers
    //1 = 1 wax
    //2 = 1 JBG
    //3 = High Five
    //4 = 3 edges
    //5 = 100 beers
}else{
    cout << "Nope!" << endl;
    return 0;
    
    //0 = -20 beers
    //1 = -1 ski equipment
    //2 = -50 beers
}
}else if(userAnswer == "2"){
    //take chances 
    if(getRelationship() == 1){
        cout << "Friend" << endl;
        return 3;
        //reward
    }else if(getRelationship() == 2){
        cout << "Neutral" << endl;
        return 4;
        //neutral
    }else{
        cout << "Unfriendly" << endl;
        return 5;
        //misfortune
    }
    //resets the NPC relationship
    setRelationship();
}else{
    //invalid input
    cout << "Invalid Input" << endl;
    return -1;
}
}
//described in NPC.h
string NPC::getNPCName(int index){
    return names.at(index);
}

string NPC::getPuzzle(int index){
return puzzles.at(index);
}
int NPC::getAnswer(int index){
    return answers.at(index);
}

int NPC::getRelationship(){
    return randRelationship;
}
void NPC::setRelationship(){
srand(time(NULL));
randRelationship = rand()%3+1;
}


