// CSCI 1300 Fall 2021
// Authors: Alex Norby and Keaton Glassman
// Recitation 212 and 213
// Project 3 -- testDriver.cpp

#include "P7.h"
#include "Jerry.h"
#include "Map.h"
#include "NPC.h"
#include "userInfo.h"
#include <iostream>
#include <vector>
#include <ctime>
using namespace std;

//creates objects for every class
 Map map;  
 Jerry jer;
 P7 p7;
 NPC npc;
 userInfo user;
 //starts with the first mountain 
 int mountainNumber = 1;
 
 //edge cases checks if you run out of maintenance, frustration > 100 or  infest > 100
void edgeCases(){
    if(user.getSkiMaintenance() <= 0){
        cout << "Game over, out of ski maintenance" << endl;
        user.makeLeaderboard();
        abort();
    }else if(user.getFrustration() >= 100){
        cout << "Rage Quit! The jerries got in your head bro, 100 frustration. " << endl;
        user.makeLeaderboard();
        abort();
    }else if(user.getInfestation() >= 100){
        cout << "The mountain has been overrun with jerries! Game over!" << endl;
        user.makeLeaderboard();
        abort();
    }
}

//Transfers stats held in p7 class to the userInfo class 
void transferStats(){
    user.setFrustration(p7.transferFrustration());
    user.setInfestation(p7.transferInfestation());
    user.setViruses(p7.transferVirus());
    user.setskiMaintenance(p7.transferMaintenance());
    int jDefeat = user.getJerriesDefeated();
    p7.setJerriesDefeated(jDefeat);

}

//every 3 moves a misfortune occurs
void runMisfortune(){
    //mis is the misfortune you get 
    int mis = rand()%10;
    //Will not drop your ski maintenance if you defeat the last jerry on the last mountain 
    int main = rand()%10;
   //30% chance of a misfortune occurring 
    if(mis == 0){
        cout << "Oh no, while you were lapping the park someone stole your backpack with some of your equipment!" << endl;
        for(int i = 0; i < 7; i++){
            int rando = rand()%7;
            int subo = rand()%5;
            if(subo <= p7.getNumSkiEquipment(rando)){
                    p7.subtractNumSkiEquipment(rando, subo);
            }else{
                 p7.subtractNumSkiEquipment(rando, p7.getNumSkiEquipment(i));
            }
                }
                p7.displayInventory();
    }else if(mis == 1){
        cout << "Oh no! You clipped a rock and hurt your skis!" << endl;
        p7.misfortune(1, 11);
    }else if(mis == 2){
        cout << "A jerry fell off the chair! +10 frustration" << endl;
      p7.misfortune(2, 11);
    }
    if((mountainNumber < 5 || (mountainNumber == 5 && user.getMoveOn() <=2)) && mis != 1){
    p7.misfortune(11, main);
    }
    
}

void runItUp(){
    //Gets username
    user.displayUser();
    //spawns the map for the first time 
    srand(time(NULL));
    p7.displayMenu();
    //spawns map 
     map.spawnP7(rand()%4+1, rand()%8+1);
            for(int i = 0; i < 3; i++){
                map.spawnJerry(rand()%4+1, rand()%8+1);
                map.spawnNPC(rand()%4+1, rand()%8+1);
            }
    


    char move;  // for storing user input

    // quit after passing the fifth mountain
    while(mountainNumber <= 5){
        //Game instructions
        if(user.getMoves() == 3){
            cout << endl << "Woaaaah there dude! Your turns are looking clean! Now that you have your feet under you start exploring the mountains!\n";
            cout << "Talk to NPCs (N) and get to know your fellow riders.\nGo to Powder 7 (P) to upgrade equipment.\nRemember, if you see any jerries, make sure to give em a good pole wacking!" << endl;
            cout << "Keep in mind you must have equipment to fight jerries, the more you upgrade your swag and poles, the less likely Jerries can even touch you bro.\nWatch out for misfortunes, this mountains got some bad JUJU." << endl;
            cout << "Safe travels " << user.getUserName() << endl;
            //game objectives
        }else if(user.getMoves() == 6){
            cout << endl;
            cout << "How many tellimark skiers does it take to screw in a light bulb?" << endl;
            cout << "Two! One screws in the bulb while the other one says 'Nice Turns Brah'" << endl << endl;
             cout << user.getUserName() << " your job is to rid this mountain of Jerries that are infesting the preious pow pow.\n";
            cout << "Keep a cool head, Jerries can be quite frustrating! If you're getting upset, kick back, chillax and watch some ski movies I got on the VHS downstairs." << endl;
            cout << "There's a lot of obstacles on the mountain, keep good care of your ski maintenance by going to the ski bench and upgrading with equipment you buy." << endl;
            cout << "If you're straight up not having a good time, just say the magic word 'Quit' and you'll be free to go." << endl;

        }
        //transfer stats and check edge cases every time the user makes a move 
       transferStats();
       edgeCases();
       map.displayMap();  // pretty print map_data in terminal
        
        
        //Displays moves 
        cout << "Valid moves are: " << endl; 
        map.displayMoves(); 
        cout << "I (Inventory)" << endl; // give user a menu of valid moves to pick from
        //if the user has defeated at least 1 jerry you can advance to next mountain
         if(user.getMoveOn() >= 1){
        cout << "p (Next Mountain)" << endl;
         }
         //if ski maintenance is down the user can repair their ski
         if(user.getSkiMaintenance() < 100){
             cout << "r (repair ski)" << endl;
         }
         //if the user is infected they are prompted to use JBG
         if(user.getViruses() > 0){
             cout << "j (Use Jerry-Be-Gone)"<<endl;
         }
         //if the user is frustrated they can watch movies to lower it 
         if(user.getFrustration() > 0){
             cout << "m (watch ski movies)" << endl;
         }

        
        cout << "Input a move: "; 
        cin >> move;
        cout << endl;
        
        //quit statement for testing code
        if(move == 'q' || move == 'Q')return;
        //executes moves and keeps track of how many moves you've made
        if(map.executeMove(move)){
            user.setMoves(user.getMoves()+1);
            //if the user is infected it drops maintenance 5 pts per move 
            if(user.getViruses() > 0 && map.isP7Location() == false){
                p7.setMaintenance(5);
                transferStats();
                cout << "Viruses: " << user.getViruses() << endl << "Ski Maintenance: " << user.getSkiMaintenance()<<endl;
            }
            //user gets 5 beers per move unless you have 2 or more top coat designs (+15)
            if(p7.getNumSkiEquipment(1) < 2){
                p7.setBeers(p7.getBeers()+5);
            }else{
                p7.setBeers(p7.getBeers()+15);
            }
            //every three moves a misfortune has a chance of occuring 
            if(user.getMoves()%3 == 0){
            runMisfortune();
            }
           // cout << "Moves: " << user.getMoves() << endl;
        }  // move the player on map based on user input
        //I displays inventory
        if(move == 'i' || move == 'I'){
            p7.displayInventory();
        }
        //J uses JBG 
        if(move == 'j' || move == 'J'){
            p7.repairVirus();
             transferStats();
        }
        //M is to watch movies
        if(move == 'm' || move == 'M'){
            p7.repairFrustration();
            transferStats();
            
        }
        //if the user wants to move mountains
        if((move == 'p' || move == 'P') && user.getMoveOn() >= 1 ){
            if(mountainNumber+1 <6){
                //transition prints the ski guy
            map.transition();
            cout << "Next Mountain: ";
            //reset player location
            map.setPlayerColPosition(0);
            map.setPlayerRowPosition(0);
            //move on checks to see if you've defeated 3 jerries and will move you onto next mountain
            user.setMoveOn(0);
            //reset the map and increment mountain number
            srand(time(NULL));
            
            mountainNumber++;
            //prints out the mountain you're on 
            if(mountainNumber == 2){
             cout << "Snow Bird" << endl;   
            }else if(mountainNumber == 3){
                cout << "Park City" << endl;
            }else if(mountainNumber == 4){
                cout << "Aspen" << endl;
            }else if(mountainNumber == 5){
                cout << "Vail" << endl;
            }else{
                mountainNumber++;

            }
            
            //sets the mountain number for other classes
            p7.setRateOfMountain(mountainNumber);
            jer.setMountain(mountainNumber);
            //resets and spawns map
            map.resetMap();
            map.spawnP7(rand()%4+1, rand()%8+1);
            for(int i = 0; i < 3; i++){
                map.spawnJerry(rand()%4+1, rand()%8+1);
                map.spawnNPC(rand()%4+1, rand()%8+1);
            }
            //sets prices in menu
            p7.setPrices(p7.getRateOfMountain());       
            }else{
                //if you beat mountain 5
                jer.setMountain(6);
            cout << "Richeous " << user.getUserName() << "! Thank you so much for getting those jerries back to Texas where they belong! If you ever wanna slay the trails again just hit my line." << endl;
        cout << "Moves: " << user.getMoves() << endl;
        cout << "Jerries Defeated: " << user.getJerriesDefeated() << endl;
                map.winGame();
                //leaderboard contains sorted algorithm and read/write files
                user.makeLeaderboard();
        
        return;
            }
         //user repairs skis
        }else if(move == 'r' && user.getSkiMaintenance()<100){
            p7.repairSki();
            transferStats();
        }
        //if you want to go to powder 7
        if (map.isP7Location()) {
            cout << "You're in a Powder 7!" << endl;
           // runMisfortune();
            p7.displayMenu();
            
        }
        //if the user stumbles across a jerry
        if (map.isJerryLocation()) {
            //finds names of jerries on different mountains 
            jer.setNames(mountainNumber, user.getMoveOn());

            cout << "You ran into " << jer.getJerryName(0) << ". Do you want to: "<< endl;
            if(user.getSkiMaintenance() > 0){
                cout << "1. Fight" << endl;
            }
            cout << "2. Forfeit" << endl;
            //transfers fighting stats
             int poleLvl = p7.getPoleLvl();
             int swaggy = p7.getSwag();
             int mNum = p7.getRateOfMountain();
             jer.setPoleLvl(poleLvl);
             jer.setSwagNum(swaggy);
             jer.setMountain(mountainNumber);
             //displayJerry returns a number based on the fight outcome or chances outcome
             int results = jer.displayJerry();
            if(results == 0){
                //defeat
                    cout << "Defeat" << endl;
                    //infestation increases
                    p7.setInfest(20);
                    //10% chance of infection
                    int virusChance = rand()%10;
                    if(virusChance == 0){
                        cout << "You've been infected!" << endl;
                        p7.setViruses(1);
                        
                    }
                    //progress +25

                    int randEquip = rand()%6;
                      bool isOut = true;
                      //looks through items in inventory, if you are out you lose the game
                 for(int i = 0; i < 7; i++){
                     if(p7.getNumSkiEquipment(i) > 0){
                         isOut = false;
                     }
                 }
                 if(isOut){
                     cout << "You ran out of parts! Game Over!" << endl;
                     user.makeLeaderboard();
                     return;
                 }
                 //finds equipment that you own at least one of 
             while(p7.getNumSkiEquipment(randEquip) <= 0){
                 randEquip = rand()%6;

             }
             //substract that equipment
             p7.subtractNumSkiEquipment(randEquip, 1);
             //display what was taken
             cout << "-1 "<< p7.getEquipment(randEquip) << endl;
            
             
            }else if(results == 1 ){
            
                //victory
                    if(user.getMoveOn()+1 < 3){
                        
                    cout << "Victory! +50 Beers" << endl;
                    //gives 50 beers
                    p7.setBeers(p7.getBeers()+50);
                    //increases jerries defeated
                    user.setJerriesDefeated(user.getJerriesDefeated()+1);
                    transferStats();
                    //move on checks if you've defeated 3 jerries/mountain
                    user.setMoveOn(user.getMoveOn()+1);
                    jer.setNames(mountainNumber, user.getMoveOn());
                  //  cout << "New Beers: " << p7.getBeers() << "\n" << "Jerries Defeated:" << user.getJerriesDefeated()<<endl;
                      int randEquip = rand()%6;
             //checks if you are out of equipment
             bool isOut = true;
                 for(int i = 0; i < 7; i++){
                     if(p7.getNumSkiEquipment(i) > 0){
                         isOut = false;
                     }
                 }
                 if(isOut){
                     cout << "You ran out of parts! Game Over!" << endl;
                     user.makeLeaderboard();
                     return;
                 }
                 //finds equipment you own at least one of 
             while(p7.getNumSkiEquipment(randEquip) <= 0 && isOut == false){
                 randEquip = rand()%6;
                 

             }
            //subtract that equipment
             p7.subtractNumSkiEquipment(randEquip, 1);
             cout << "-1 "<< p7.getEquipment(randEquip) << endl;
                    }else{
                        user.setMoveOn(3);
                        user.setJerriesDefeated(user.getJerriesDefeated()+1);
                        mountainNumber++;
                    }

            //if the user has defeated 3 jerries in the mountain, reset map and move to next mountain
            if(user.getMoveOn() >= 3){
                user.setMoveOn(0);
                 
                if(mountainNumber < 6){
                    //happens when you defeat all three jerries in the mountain
                    map.transition();
                cout << "3 Jerries Defeated! Next Mountain: ";
                p7.setInfest(5);
                }else{
                   //win the game 
            cout << "Richeous " << user.getUserName() << "! Thank you so much for getting those jerries back to Texas where they belong! If you ever wanna slay the trails again just hit my line." << endl;
  cout << "Moves: " << user.getMoves() << endl;
        cout << "Jerries Defeated: " << user.getJerriesDefeated() << endl;
      
  //      cout << "Jerries Defeated: " << user.getJerriesDefeated() << endl;
                    map.winGame();
                    user.makeLeaderboard();
             
                    }
                //resets jerries defeated in the next mountain
                user.setMoveOn(0);
                 srand(time(NULL));
                 //resets player location
            map.setPlayerColPosition(0);
            map.setPlayerRowPosition(0);
          //prints mountain name
            if(mountainNumber == 2){
             cout << "Snow Bird" << endl;   
            }else if(mountainNumber == 3){
                cout << "Park City" << endl;
            }else if(mountainNumber == 4){
                cout << "Aspen" << endl;
            }else if(mountainNumber == 5){
                cout << "Vail" << endl;
            }
            //sets mountain number for classes and spawns map 
            p7.setRateOfMountain(mountainNumber);
            jer.setMountain(mountainNumber);
            map.resetMap();
            map.spawnP7(rand()%4+1, rand()%8+1);
            for(int i = 0; i < 3; i++){
                map.spawnJerry(rand()%4+1, rand()%8+1);
                map.spawnNPC(rand()%4+1, rand()%8+1);
            }
            //sets prices
            p7.setPrices(p7.getRateOfMountain());       
            }
            }else{
                //if you forfeit, set all equipment = 0
                cout << "Forfeit" << endl;
                for(int i = 0; i < 7; i++){
                    p7.subtractNumSkiEquipment(i, p7.getNumSkiEquipment(i));
                }
               
                
            
                
                
            }
             
        runMisfortune();
        }
    //if user approaches an NPC
        if (map.isNPCLocation()) {
            //check depends on if the NPC is friendly or if you got the riddle correct
          int check = npc.displayNPC();
            if(check == 1){
                //correct answer
                int randPrize = rand()%5;
                //decides what prize to give you
                switch(randPrize){
                    case 0:
                    //+50 beers
                    p7.setBeers(p7.getBeers()+50);
                    cout << "+50 Beers!" << endl;
                    cout << "You now have: "<< p7.getBeers() << " beers" << endl;
                    break;
                    case 1:
                    //+wax
                    if(p7.getNumSkiEquipment(2)+1 <= 5){
                    p7.setNumSkiEquipment(2, 1);
                    cout << "+1 Bar of Wax" << endl;
                    }else{
                        cout << "Have enough wax?" << endl;
                    }
                       
                    break;
                    case 2: 
                    //+JBG
                    if(p7.getNumJBG()+1 <=5){
                    p7.setNumJBG(p7.getNumJBG()+1);
                    cout << "+1 Can of Jerry-Be-Gone" << endl;
                    }else{
                        cout << "We would give you Jerry-Be-Gone, but you already have enough" << endl;
                    }
                       
                    break;
                    case 3:
                    //nothing
                    cout << "High Five Bro" << endl;
                    break;
                    case 4:
                    //best reward
                    if(p7.getNumSkiEquipment(3)+3 <=5){
                    p7.setNumSkiEquipment(3, 3);
                    cout << "+3 Ski Edges" << endl;
                    }else if(p7.getNumSkiEquipment(3)+1 <= 5){
                        cout << "+1 Ski Edge" << endl;
                        p7.setNumSkiEquipment(3, 1);
                    }else{
                        cout << "Have a Yerba Mate on the House" << endl;
                    }
                       
                    break;
                    default:
                    //+100 beers
                    p7.setBeers(p7.getBeers()+100);
                    cout << "+100 Beers" << endl;
                    cout << "You now have: "<< p7.getBeers() << " beers" << endl;
                    break;
             
             
                
            }

        }else if(check == 0){
            //answer is wrong find misfortune
                    int randMisfortune = rand()%3;
                    switch(randMisfortune){
                        case 0:
                        //-20 beers
                        if(p7.getBeers()-20 > 0){
                        p7.setBeers(p7.getBeers()-20);
                        cout << "-20 Beers" << endl;
                        cout << "You now have: "<< p7.getBeers() << " beers" << endl;

                        } else {
                            //dont do anything if it you have less than 20 beers
                            cout << "Dissapointing Bro" << endl;
                        }
                        break;
                        case 1:

                        //takes away a random piece of equipment
                         if(p7.getNumSkiEquipment(randMisfortune) > 0){
                         p7.subtractNumSkiEquipment(randMisfortune, 1);
                         cout << "-1 "<< p7.getEquipment(randMisfortune) << endl;

                         //sees if you still have equipment
                           bool isOut = true;
                 for(int i = 0; i < 7; i++){
                     if(p7.getNumSkiEquipment(i) > 0){
                         isOut = false;
                     }
                 }
                 if(isOut){
                     cout << "You ran out of parts! Game Over!" << endl;
                     user.makeLeaderboard();
                     return;
                 }
                           
                         }else{
                             //if we can't take away a piece of equipment, just be dissapointed 
                             cout << "Dissapointing Bro" << endl;
                         }
                        break;
                        default:
                        if(p7.getBeers()-50 > 0){
                        p7.setBeers(p7.getBeers()-50);
                        cout << "-50 Beers" << endl;
                        cout << "You now have: "<< p7.getBeers() << " beers" << endl;

                        }else{
                            cout << "Dissapointing Bro" << endl;
                        }
                        break;
                    }
                
        }else if(check == 3){
            //NPC is a friend 
            int randEquip = rand()%6;
            //finds a piece of equipment < 5
            while(p7.getNumSkiEquipment(randEquip)+1 > 5){
                randEquip = rand()%6;
            }
            //adds one to equipment
            p7.setNumSkiEquipment(randEquip, 1 );
            cout << "+1 " << p7.getEquipment(randEquip) << endl;
         
        }else if(check == 4){
            //NPC is neutral nothing happens
            cout << "Just let him ski" << endl;

        }else{
            //NPC is unfriendly 
       
             int randEquip = rand()%6;
             //sees if you are out of equipment
               bool isOut = true;
                 for(int i = 0; i < 7; i++){
                     if(p7.getNumSkiEquipment(i) > 0){
                         isOut = false;
                     }
                 }
                 if(isOut){
                     cout << "You ran out of parts! Game Over!" << endl;
                     user.makeLeaderboard();
                     return;
                 }
                      //finds equipment you have at least one of 
             while(p7.getNumSkiEquipment(randEquip) <= 0){
                 randEquip = rand()%6;

             }
             //substracts one from equipment
             p7.subtractNumSkiEquipment(randEquip, 1);
             cout << "-1 "<< p7.getEquipment(randEquip) << endl;
             
            

        }
        runMisfortune();
        //change relationship of NPC
        npc.setRelationship();
    }
        
    }

  if(jer.getMountain()< 6){
      //will say new mountain as long as you haven't won
    cout << "New Mountain: " << jer.getMountain() << endl;
  }
  //if you beat mountain 5
   
 
}

int main(){

    runItUp();
}
   


    //p7.setMountainRate(p7.getMountainNum()+1);

    
    
  
    
  
    //pass poleLvl through jerry.setFight();


    


    //how do we get Jer;


