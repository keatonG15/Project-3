// CSCI 1300 Fall 2021
// Authors: Alex Norby and Keaton Glassman
// Recitation 212 and 213
// Project 3 -- NPC.h

#include <iostream>
#include <vector>
#include <string>
using namespace std;
 #ifndef NPC_H //Helps call a class
 #define NPC_H // Defines the class

// vector<string>names
// Int randRelationship
// vector<string>puzzles  // answer riddle
// Bool isJerry = false;
class NPC{

public: 
NPC();//dafault
NPC(vector<string>names, vector<string>puzzles, int randRelationship, bool isJerry);//parameterized

int displayNPC();//displays NPC interaction

string getNPCName(int index);//gets the NPC names to display


string getPuzzle(int index);//finds a random question
void setPuzzle();//sets the puzzles in a vecotr
int getAnswer(int index);//gets the answer for a puzzle

int getRelationship();//finds chances of NPC
void setRelationship();//sets chances of NPC


int getReward();//gets rewards 
void setReward();//sets rewards

//publicly accessed by other classes
vector<string>names;
vector<string>puzzles;
vector<int>answers;
int randRelationship;

//private to NPC
private: 
int randName;
bool isJerry;

};
#endif