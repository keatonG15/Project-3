
#include <iostream>
#include <vector>
#include <string>
using namespace std;
 #ifndef NPC_H //Helps call a class
 #define NPC_H // Defines the class

// vector<string>names
// Int randRelationship
// vector<string>puzzles  // answer riddle
// Bool isJerry = false;
class NPC{
public: 
NPC();
NPC(vector<string>names, vector<string>puzzles, int randRelationship, bool isJerry);

int displayNPC();

string getNPCName(int index);


string getPuzzle(int index);
void setPuzzle();
int getAnswer(int index);

int getRelationship();
void setRelationship();


int getReward();
void setReward();

vector<string>names;
vector<string>puzzles;
vector<int>answers;
int randRelationship;


private: 
int randName;
bool isJerry;

};
#endif