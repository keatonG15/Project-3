// CSCI 1300 Fall 2021
// Authors: Alex Norby and Keaton Glassman
// Recitation 212 and 213
// Project 3 -- P7.cpp

using namespace std;
#include <iostream>
#include <string>
#include <vector>
#include "P7.h"
#include "Jerry.h"
#include "NPC.h"
#include "userInfo.h"

//hold is made to temporarily get values related to the user and then we transfer stats later on 
userInfo hold;
P7::P7(){
    //sets everything blank and base prices of mountain
    indexOfSkiEquipment = 0;
    //numOfSkiEquipment;
    for(int i = 0; i < numOfSkiEquipment.size(); i++){
    numOfSkiEquipment.at(i) = 0;
    }
 int arr[7] = {10, 20, 5, 15, 5, 10, 100};
    for(int x = 0; x < 7; x++){
        prices.push_back(arr[x]);
    }
    for(int c = 0; c < 7; c++){
        numOfSkiEquipment.push_back(0);
      //  cout << numOfSkiEquipment.at(i) << endl;
    }
    //sets equipment names 
        string arr2[7] = {"Fiber Glass Core", "Top Coat Design", "Wax", "Edges", "Ski Pass", "Bindings", "Full Ski"};
    for(int i = 0; i < 7; i++){
    equipment.push_back(arr2[i]);
   // cout << equipment.at(i) << endl;
    }
    //base info for user
numJBG = 0;
swag = 0;
poleLvl = 1;
beers = 200;
numSkis = 1;
rateOfMountain = 0;


}

P7::P7(int index, vector<int>numEquipment, int JBG, int numSwag, int pole, int broken, int beers, double rate){
    //same as default with parameters 
    indexOfSkiEquipment = index;
    for(int i = 0; i < numEquipment.size(); i++){
        numOfSkiEquipment[i] = numEquipment[i];
    }
    for(int x = numEquipment.size(); x < numOfSkiEquipment.size(); x++){
        numOfSkiEquipment[x] = 0;
    }
    numJBG = JBG;
    swag = numSwag;
    poleLvl = pole;
    beers = beers;
    numSkis = broken;
    rateOfMountain = rate;
}

void P7::displayEquipment(){

   // cout << "Rate: " << getRateOfMountain() << endl;
   //sets prices depending on the mountain number
  setPrices(getRateOfMountain());
    string input,  quan;
    while(input != "8"){
        
    cout << "=====Welcome to the Equipment Isle=====" << endl;
//displays each piece of equipment and its price
    for(int i = 1; i <= equipment.size(); i++){
        cout << i << ". " << equipment.at(i-1) << " = " << prices.at(i-1)<< endl;
    }
    cout << "8. Leave\n" << endl;
    cout << "Beers: " << getBeers() << endl;
   //What equipment would you like to buy
    cout << "What would you like to buy?" << endl;
    cin >> input;
    //leave
     if(input == "8"){
         
         displayMenu();
         return;
     }
     //quantity
    cout << "How many?" << endl;
    cin >> quan;
    int quantity = 0;
    //quantityt is stored as int if the input is correct
    if(quan.length() == 1 && quan[0] > 47 && quan[0] < 57){
        quantity = stoi(quan);
    }
    //increase frustration and change maintenance if you have a virus 
     hold.setFrustration(hold.getFrustration()+2);
     hold.setskiMaintenance(hold.getSkiMaintenance()-(hold.getViruses()*10));
    cout << "Frustration: " << hold.getFrustration() << endl;
    cout << "Ski Maintenance: "<< hold.getSkiMaintenance() << endl;
//checks invalid input 
    if(input != "1" && input != "2" && input != "3" && input != "4" && input != "5" && input != "6" && input != "7" && input != "8"){
        cout << "Invalid Input." << endl;
        //checks if you are buying too much 
    }else if(quantity + getNumSkiEquipment(stoi(input)-1)  > 5){
        cout << "Can't buy more than 5 items" << endl;
    }else{
        //go through with transaction
        if(getBeers()-(quantity*prices[stoi(input)-1])>=0){
    setNumSkiEquipment(stoi(input)-1, quantity);
    setBeers(getBeers()-(quantity*prices[stoi(input)-1]));
    cout << "You bought: " << quantity << " " << getEquipment(stoi(input)-1) << endl;
    cout << "You have: " << getBeers() << " beers." << endl;
        }else{
            //if not you are out of money 
        cout << "Insufficient Funds." << endl;
        }
    }
    }
 
}
void P7:: displayInventory(){
//displays each item in the inventory

    for(int i = 0; i < equipment.size(); i++){
        cout << i+1 << ". "<< equipment.at(i) << ": " << getNumSkiEquipment(i) << endl;
    }
    
    
    cout << "JBG cans: " << getNumJBG() << endl;
    cout << "Swag: " << getSwag() << endl;
    cout << "Pole Lvl: " << getPoleLvl() << endl;
    cout << "Beers Left: " << getBeers() << endl;
    cout << "---------------" << endl;
    //displays stats 
    cout << "Frustration: " << hold.getFrustration() << endl;
    cout << "Infestation: " << hold.getInfestation() <<"%" <<endl;
    cout << "Ski Maintenance: " << hold.getSkiMaintenance() << endl;
    cout << "Viruses: " << hold.getViruses() << endl;
    cout << "Jerries Defeated: " << hold.getJerriesDefeated() << endl;
  

}
void P7::displayMenu(){
    //displays overall menu
    string input = "0", quan;
    int quantity = 0;
  
    
    while(input != "5" ){
       //displays menu 
    cout << "=====Welcome to Powder Seven=====" << endl;
    cout << "1. Buy Ski Equipment(varies)\n2. Buy Jerry-Be-Gone\n3. Buy Swag\n4. Upgrade Poles(varies)\n5. Leave\n6. Inventory"<<endl;
    cout << "Beers: " << getBeers() << endl;
   //asks what you want 
    cout << "What would you like to buy?" << endl;
    cin >> input;

  

    
   if(input.length()>1)return;

    if(input == "1"){
        //takes you to sub-menu to buy equipment
        displayEquipment();
    }else if (input == "2"){
        //asks how many JBG cans 
        cout << "Jerry-Be-Gone: " << (10*rateOfMountain)+10 << " beers"<<endl;
        cout << "How many?" << endl;
        cin >> quan;
        //converts it ot int if input is valid
        if(quan.length() == 1 && quan[0] > 47 && quan[0] < 54){
        quantity = stoi(quan);
    }

         hold.setFrustration(hold.getFrustration()+2);
              hold.setskiMaintenance(hold.getSkiMaintenance()-(hold.getViruses()*10));

//checks if you are buying too much
        if(quantity + getNumJBG() > 5){
            cout << "Can't have more than 5 of these items" << endl;
            displayMenu();
            //go through with transaction
        }else if(getBeers()-(quantity*((10*rateOfMountain)+10)) >=0){
        setBeers(getBeers()-(quantity*((10*rateOfMountain)+10)));
        setNumJBG(getNumJBG() + quantity);
         cout << "You bought: " << quantity << " cans." << endl;
        cout << "You have: " << getBeers() << " beers." << endl;
        displayMenu();
        }else{
            //not enough money 
            cout << "Insufficient Funds." << endl;
            displayMenu();
        }
       
    }else if(input == "3"){
        cout << "Swag: " << (20*rateOfMountain)+20 << " beers"<<endl;
        cout << "How many?" << endl;
        cin >> quan;
        //converts to int if input is correct
        if(quan.length() == 1 && quan[0] > 47 && quan[0] < 51){
        quantity = stoi(quan);
    }
         hold.setFrustration(hold.getFrustration()+2);
              hold.setskiMaintenance(hold.getSkiMaintenance()-(hold.getViruses()*10));

    cout << "Frustration: " << hold.getFrustration() << endl;
    cout << "Ski Maintenance: "<< hold.getSkiMaintenance() << endl;
//makes sure you're not buying too much
        if(quantity + getSwag() > 2){
            cout << "Can't have more than 2 of these items." << endl;
            displayMenu();
            //go through with transaction5

        }else if(getBeers()-(quantity*(20*rateOfMountain)+20) >= 0){
        setSwag(getSwag() + quantity);
        setBeers(getBeers()-(quantity*(20*rateOfMountain)+20));
        cout << "You bought: " << quantity << " clothing items." << endl;
        cout << "You have: " << getBeers() << " beers." << endl;
        displayMenu();
        }else{
            //out of money 
            cout << "Insufficient Funds." << endl;
            displayMenu();
        }

    }else if(input == "4"){
        cout << "Enter what level you want" << endl;
        cout << "Lvl 2: " << (10*rateOfMountain)+10 << "\nLvl 3: "<< (25*rateOfMountain)+25 << "\nLvl 4: "<< (40*rateOfMountain)+40 << "\nLvl 5: "<< (50*rateOfMountain)+50 << "\n6. Leave" << endl;
        cin >> quan;
        //converts to int if input is valid 
        if(quan.length() == 1 && quan[0] > 49 && quan[0] < 55){
        quantity = stoi(quan);
    }

         hold.setFrustration(hold.getFrustration()+2);
              hold.setskiMaintenance(hold.getSkiMaintenance()-(hold.getViruses()*10));

    cout << "Frustration: " << hold.getFrustration() << endl;
    cout << "Ski Maintenance: "<< hold.getSkiMaintenance() << endl;

//sets pole level depending on input 
        if(quantity == 2){

            //chekcs if you have the funds
            if(getBeers()- ((10*rateOfMountain)+10) >= 0){
                //remove cost and set pole lvl
                 setBeers(getBeers()-((10*rateOfMountain)+10));
                 setPoleLvl(quantity);
                 displayMenu();
             }else{
                cout << "Insufficient Funds." << endl;
                displayMenu();
            }
        }else if(quantity == 3){
            //rest of quantity conditionals are the same 
            if(getBeers()-((25*rateOfMountain)+25) >= 0){
                 setBeers(getBeers()-((25*rateOfMountain)+25));
                 setPoleLvl(quantity);
                 displayMenu();

            }else{
                cout << "Insufficient Funds." << endl;
                displayMenu();
            }

        }else if(quantity == 4){
            if(getBeers()-((40*rateOfMountain)+40)>=0){
                setBeers(getBeers()-((40*rateOfMountain)+40));
                setPoleLvl(quantity);
                displayMenu();

            }else{
                cout << "Insufficient Funds." << endl;
                displayMenu();
            }
        }else if(quantity == 5){
            if(getBeers()-((50*rateOfMountain)+50)>=0){
            setBeers(getBeers()-((50*rateOfMountain)+50));
            setPoleLvl(quantity);
            displayMenu();

            }else{
                cout << "Insufficient Funds." << endl;
                displayMenu();
            }
        }else if(quantity > 5){
           cout << "Can't take more than 5"<< endl;
           displayMenu();
            return;
        }else{
            cout << "Invalid Input." << endl;
            displayMenu();

        }

    }else if(input == "5"){
        cout << "Goodbye" << endl;
      
        
        return;
    }else if(input == "6"){
        displayInventory();
        displayMenu();
        
        }else{
        cout << "Invalid Input" << endl;
        displayMenu();
        return;
    }
    
 
return;
    }
    return;
  
}
//next 18 classes are described in P7.h 
int P7::getNumSkiEquipment(int indexOfSkiEquipment){
  
    if(numOfSkiEquipment.at(indexOfSkiEquipment) > 5){
        setNumSkiEquipment(indexOfSkiEquipment, 5);
        return 5;
    }else{
    return numOfSkiEquipment.at(indexOfSkiEquipment);
    }
}
void P7::setNumSkiEquipment(int indexOfSkiEquipment, int value){
  // cout << indexOfSkiEquipment << endl;
  int num = getNumSkiEquipment(indexOfSkiEquipment);
 // cout << num << endl;
 
    numOfSkiEquipment.at(indexOfSkiEquipment) = num+value; 
 
}

void P7::subtractNumSkiEquipment(int index, int value){
    int num = getNumSkiEquipment(index);
    if(num-value >= 0){
    numOfSkiEquipment.at(index) = num - value;
    }else{
        numOfSkiEquipment.at(index) = 0;
    }

}

string P7::getEquipment(int index){
    return equipment[index];
}

double P7::getPrice( int index){
    return prices[index];
}
void P7::setPrices(double rate){
    prices.clear();
    int arr[7] = {10, 20, 5, 15, 5, 10, 100};
  
    for(int i = 0; i < 7; i++){
       // cout << prices.at(i)*rate << endl;
    prices.push_back((arr[i]*rate)+arr[i]);
 //  cout << prices.at(i) << endl;
    }
}

int P7::getNumJBG(){
    return numJBG;
}
void P7::setNumJBG(int input){
    numJBG = input;
}

int P7::getSwag(){
    return swag;
}
void P7::setSwag(int input){
    swag = input;
}
int P7::getPoleLvl(){
    return poleLvl;
}
void P7::setPoleLvl(int input){
    poleLvl = input;
}

int P7::getSkis(){
    return numSkis;
}
void P7::setSkis(int value){
    numSkis = value;
}

int P7::getBeers(){
    return beers;
}
void P7::setBeers(int value){
    beers  = value;
}

double P7::getRateOfMountain(){
    return rateOfMountain;
}
void P7::setRateOfMountain(double mountainNumber){
    //the higher up your mountain is, the more expensive P7 is
    
    if(mountainNumber == 2){
        rateOfMountain = .1;
    }else if(mountainNumber == 3){
        rateOfMountain = .2;
    }else if(mountainNumber == 4){
        rateOfMountain = .25;
    }else if(mountainNumber == 5){
        rateOfMountain = .3;
    }else{
        rateOfMountain == 0;
    }
 
}
void P7::repairSki(){
    cout << endl;
    string equ = "0";
    int quantity = 0;
    //cant repair with virus 
    if(hold.getViruses() > 0){
        cout << "You can't repair your skis with a virus!" << endl;
        return;
    }
    cout << "====Ski Bench===="<<endl;
  
    while(equ != "8" && hold.getSkiMaintenance() < 100){
          displayInventory();
    cout << "8. Leave" << endl;
        cout << "What part(s) would you like to repair with?" << endl;
        cin >> equ;
         int selection = 0;
         //converts input to int if input is valid 
        if(equ.length() == 1 && equ[0] > 47 && equ[0] < 57 ){
         selection = stoi(equ);
        }
//will repair 20 maintenance per equipment 
        switch(selection){
            //all cases are identical except for the index of removal
                case(1):
                //makes sure you have enough equipment 
                if(getNumSkiEquipment(selection-1) > 0){
                    cout << "How many?" << endl;
                    cin >> quantity;
                    //fully repair ski and remove the quantity of equipment chosen 
                     if(hold.getSkiMaintenance() + (20*quantity) > 100 && getNumSkiEquipment(selection-1) >= quantity){
                         hold.setskiMaintenance(100);
                         subtractNumSkiEquipment(selection-1, quantity);

                //repairs ski 20 per item 
                     }else if(getNumSkiEquipment(selection-1) >= quantity && hold.getSkiMaintenance() + (20*quantity) <= 100){
                        subtractNumSkiEquipment(selection-1, quantity);
                        hold.setskiMaintenance(hold.getSkiMaintenance() + 20*quantity);
                    }else{
                        //donesnt have neough equipment 
                        cout << "You don't have enough" << endl;
                    }
                }else{
                    cout << "You don't have any " << getEquipment(selection-1) << endl;
                }
                break;
                //cases 2-6 are same as 1 
                case(2):
                if(getNumSkiEquipment(selection-1) > 0){
                    cout << "How many?" << endl;
                    cin >> quantity;
                     if(hold.getSkiMaintenance() + (20*quantity) > 100 && getNumSkiEquipment(selection-1) >= quantity){
                         hold.setskiMaintenance(100);
                         subtractNumSkiEquipment(selection-1, quantity);

                     }else if(getNumSkiEquipment(selection-1) >= quantity && hold.getSkiMaintenance() + (20*quantity) <= 100){
                        subtractNumSkiEquipment(selection-1, quantity);
                        hold.setskiMaintenance(hold.getSkiMaintenance() + 20*quantity);
                    }else{
                        cout << "You don't have enough" << endl;
                    }
                }else{
                    cout << "You don't have any " << getEquipment(selection-1) << endl;
                }
                break;
                case(3):
                if(getNumSkiEquipment(selection-1) > 0){
                    cout << "How many?" << endl;
                    cin >> quantity;
                     if(hold.getSkiMaintenance() + (20*quantity) > 100 && getNumSkiEquipment(selection-1) >= quantity){
                         hold.setskiMaintenance(100);
                         subtractNumSkiEquipment(selection-1, quantity);

                     }else if(getNumSkiEquipment(selection-1) >= quantity && hold.getSkiMaintenance() + (20*quantity) <= 100){
                        subtractNumSkiEquipment(selection-1, quantity);
                        hold.setskiMaintenance(hold.getSkiMaintenance() + 20*quantity);
                    }else{
                        cout << "You don't have enough" << endl;
                    }
                }else{
                    cout << "You don't have any " << getEquipment(selection-1) << endl;
                }
                break;
                case(4):
                if(getNumSkiEquipment(selection-1) > 0){
                    cout << "How many?" << endl;
                    cin >> quantity;
                      if(hold.getSkiMaintenance() + (20*quantity) > 100 && getNumSkiEquipment(selection-1) >= quantity){
                         hold.setskiMaintenance(100);
                         subtractNumSkiEquipment(selection-1, quantity);

                     }else if(getNumSkiEquipment(selection-1) >= quantity && hold.getSkiMaintenance() + (20*quantity) <= 100){
                        subtractNumSkiEquipment(selection-1, quantity);
                        hold.setskiMaintenance(hold.getSkiMaintenance() + 20*quantity);
                    }else{
                        cout << "You don't have enough" << endl;
                    }
                }else{
                    cout << "You don't have any " << getEquipment(selection-1) << endl;
                }
                break;
                case(5):
                if(getNumSkiEquipment(selection-1) > 0){
                    cout << "How many?" << endl;
                    cin >> quantity;
                    if(hold.getSkiMaintenance() + (20*quantity) > 100 && getNumSkiEquipment(selection-1) >= quantity){
                         hold.setskiMaintenance(100);
                         subtractNumSkiEquipment(selection-1, quantity);

                     }else if(getNumSkiEquipment(selection-1) >= quantity && hold.getSkiMaintenance() + (20*quantity) <= 100){
                        subtractNumSkiEquipment(selection-1, quantity);
                        hold.setskiMaintenance(hold.getSkiMaintenance() + 20*quantity);
                    }else{
                        cout << "You don't have enough" << endl;
                    }
                }else{
                    cout << "You don't have any " << getEquipment(selection-1) << endl;
                }
                break;
                case(6):
                if(getNumSkiEquipment(selection-1) > 0){
                    cout << "How many?" << endl;
                    cin >> quantity;
                      if(hold.getSkiMaintenance() + (20*quantity) > 100 && getNumSkiEquipment(selection-1) >= quantity){
                         hold.setskiMaintenance(100);
                         subtractNumSkiEquipment(selection-1, quantity);

                     }else if(getNumSkiEquipment(selection-1) >= quantity && hold.getSkiMaintenance() + (20*quantity) <= 100){
                        subtractNumSkiEquipment(selection-1, quantity);
                        hold.setskiMaintenance(hold.getSkiMaintenance() + 20*quantity);
                    }else{
                        cout << "You don't have enough" << endl;
                    }
                }else{
                    cout << "You don't have any " << getEquipment(selection-1) << endl;
                }
                break;
                case(7):
                //if you use a full ski you automatically get 100 maintenance
                if(getNumSkiEquipment(selection-1) > 0){
                    
                        subtractNumSkiEquipment(selection-1, 1);
                        hold.setskiMaintenance(100);
                    
                }else{
                    cout << "You don't have any " << getEquipment(selection-1) << endl;
                }
                break;
                case(8):
                cout << "Ski Mainenance: " << hold.getSkiMaintenance() << endl;
                return;
                break;

                default:
                cout << "Invalid Input." << endl;
                selection = 0;
                break;

                displayInventory();

        }
    }
    if(hold.getSkiMaintenance() == 100){
    cout << "Ski fully repaired! Get back out there!" << endl;
    }else{
        cout << "Ski's looking better!"<<endl;
    }
}
void P7::repairVirus(){
//user has option to use can to remove virus
    string decision = "0";
            if(hold.getViruses() > 0 && getNumJBG() > 0){
            cout << "Number of JBG cans: " << getNumJBG() << endl;
            cout << "Would you like to use one? 1.Yes 2.No" << endl;
            cin >> decision;
            if(decision == "1"){
                hold.setViruses(0);
                
                setNumJBG(getNumJBG()-1);
            }else{
                cout << "You didn't use a can" << endl;
            }
            }else{
                cout << "You don't have any JBG" << endl;
            }
           
}
//sets infestation if user is defeated by jerry
void P7::setInfest(int value){
    hold.setInfestation(hold.getInfestation()+value);

}
//sets viruses 
void P7::setViruses(int value){
   hold.setViruses(hold.getViruses()+value);
}
void P7::repairFrustration(){
    //user can pick a movie to watch to decrease frustration 
    string movie;
    cout << "Let's help lower your frustration!" << endl;
    int bestMovie = rand()%10;
    cout << "Pick a movie:\n1.Magma\n2.Gnar\n3.Zig Zag\n4.Novia\n5.Roots\n6.August Light\n7.Black Diamond Rush\n8.SLVSH\n9.Like a Lion\n10.Ski School"<<endl;
    cin >> movie;
    //if user picks the best movie, they lose all frustratoin 
    if(stoi(movie) == bestMovie){
             cout << "That movie crushed the vibes!" << endl;
        hold.setFrustration(0);
       
    }else{
        //if not decrease frustration by 5
        cout << "What a nice movie" << endl;
        if(hold.getFrustration()-5 >=0){
        hold.setFrustration(hold.getFrustration()-5);
        }else{
            hold.setFrustration(0);
        }
    }
cout << "Frustration: "<< hold.getFrustration() << endl;


}
void P7::misfortune(int mis, int main){
    //drops ski maintenance by 30 or 10
    if(mis == 1){
        if(hold.getSkiMaintenance() > 30){
        hold.setskiMaintenance(30);
        
        }else{
            hold.setskiMaintenance(hold.getSkiMaintenance()-10);
           
        }
         main = 3;
         displayInventory();
         //increases frustration by 10
    }else if(mis == 2){
        hold.setFrustration(hold.getFrustration()+10);
        displayInventory();
    }
    //drops ski maintenance
    if(main == 0 || main == 1 || main == 2){
        cout << "Ski maintenance dropped 10" << endl;
        hold.setskiMaintenance(hold.getSkiMaintenance()-10);
        displayInventory();
        
    }
}
//rest described in P7.h 
void P7::setMaintenance(int value){
    hold.setskiMaintenance(hold.getSkiMaintenance()-value);
}
void P7::setJerriesDefeated(int val){
    hold.setJerriesDefeated(val);
}
int P7::getJerriesDefeated(){
    return hold.getJerriesDefeated();
}

int P7::transferFrustration(){
    return hold.getFrustration();
}
    int P7::transferInfestation(){
        return hold.getInfestation();

    }
    int P7::transferVirus(){
        return hold.getViruses();

    }
    int P7::transferMaintenance(){
        return hold.getSkiMaintenance();
    }
