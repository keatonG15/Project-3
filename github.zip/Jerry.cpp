// CSCI 1300 Fall 2021
// Authors: Alex Norby and Keaton Glassman
// Recitation 212 and 213
// Project 3 -- Jerry.cpp

#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include "Jerry.h"
#include "P7.h"
using namespace std;

Jerry::Jerry(){
    //sets names to default and sets base variables
    string jerryNames[7] = {"Jer-Bear", "Jerferson Airplane", "Jereatha Franklin", "Jerrrome", "Jerred", "Jerriah", "Jerremy"};
    for(int i = 0; i < 7; i++){
        jNames.push_back(jerryNames[i]);
    }
    srand(time(NULL));

    randNumber1 = rand()%6+1;
    randNumber2 = rand()%6+1;
    poleLevel = 1;
    mountainNumber = 1;
    swag = 0;
}
Jerry::Jerry(vector<string>name, int pL, int r1, int r2, int mountNum, int swagNum){
    //same as default with specific parameters 
    for(int i = 0; i < name.size(); i++){
        jNames.push_back(name.at(i));
    }
    for(int x = name.size(); x < jNames.size(); x++){
        jNames.push_back("Jerry");
    }
    poleLevel = pL;
    randNumber1 = r1;
    randNumber2 = r2;
    mountainNumber = mountNum;
    swag = swagNum;
}
int Jerry::displayJerry(){
    //This is called when you are in a Jerry location 
    srand(time(NULL));
    string userInput;
    //choose to fight or forfeit 
    cin>>userInput;

    if(userInput == "1"){
        //fight
        randNumber1 = rand()%6 +1;
        randNumber2 = rand()%6 + 1;
        //cout << "Fight Results: " << endl;
      //  cout << "R1: " <<randNumber1 << " R2: "<< randNumber2<<endl;
      //simulates fight 
        setFight(poleLevel, randNumber1, randNumber2, mountainNumber, swag);
        //get results is whether or not you won the fight
        if(getResults() == true){
            return 0;
        }else{     
            return 1;
        }
   }else if(userInput == "2"){
       // cout << "Forfeit" << endl;
        return -1;
        //setNumSkiParts = 0
    }else if(userInput != "1" || userInput != "2"){
        cout << "Invalid Input" << endl;
        return -2;
    }
return 0;
}
string Jerry::getJerryName(int index){
    return jNames.at(index);
}
bool Jerry::getResults(){
    return isDefeated;
}
   void Jerry::setFight(int pL, int r1, int r2, int mountNum, int swagNum){
    //if left > right you win 
       double maxLeft = pL*r1;
       double maxRight = (r2*mountNum)*(1/(double)swagNum);
      // cout << "Poles: " << pL << "\n Swag: " << swagNum << "\n Mountain: " << mountNum << endl;
    
       //need to assign parameters using info from P7 class...
      if(maxLeft > maxRight){
        isDefeated = false;
        }else{
        isDefeated = true;
        }
   } 

   int Jerry::getMountain(){
       return mountainNumber;
   }
   void Jerry::setMountain(int value){
       //we use decimals becasue p7 can only pass through rates of the menu, else we set it equal to other class inputs 
       if(value == 0){
    mountainNumber = 1;
    }else if(value==.1){
        mountainNumber = 2;
    }else if(value ==.2){
      mountainNumber = 3;
    }else if(value == .25){
        mountainNumber = 4;
    }else if(value == .3){
        mountainNumber = 5;
    }else{
        mountainNumber = value;
    }

       // //mountainNumber = value;
   }
   
   void Jerry::setNames(int mountNum, int remove){
       jNames.clear();
       //different names for different mountains 
         string mountOne[3] = {"Jer-Bear", "Jerferson Airplane", "Jereatha Franklin"};
         string mountTwo[3] = {"Jerrrome", "Jerred", "Jerriah"};
         string mountThree[3] = {"Jerremy", "Jerry", "Jerkson"};
         string mountFour[3] = {"Jersica", "Jeckyl", "Jerby"};
         string mountFive[3] = {"Jerbraltar", "Jerbediah", "Jeronamo"};

         //sets names depending on your mountain 
       if(mountNum == 1){
             for(int i = 0; i < 3; i++){
                  jNames.push_back(mountOne[i]);
             }
       }else if(mountNum == 2){
             for(int i = 0; i < 3; i++){
                  jNames.push_back(mountTwo[i]);
             }
       }else if(mountNum == 3){
             for(int i = 0; i < 3; i++){
                  jNames.push_back(mountThree[i]);
             }
       }else if(mountNum == 4){
             for(int i = 0; i < 3; i++){
                  jNames.push_back(mountFour[i]);
             }
       }else{
             for(int i = 0; i < 3; i++){
                  jNames.push_back(mountFive[i]);
             }
       }
       //if you defeat a jerry, their name is removed from the list so you can't interact with them again 
       for(int x = 0; x < remove; x++){
           jNames.erase(jNames.begin(), jNames.begin()+1);
       }
   }

  int Jerry::getSwagNum(){
      return swag;
  }
   void Jerry::setSwagNum(int num){
       swag = num;
   }

   int Jerry::getPoleLvl(){ 
       return poleLevel;
   }
   void Jerry::setPoleLvl(int lvl){
       poleLevel = lvl;
   }