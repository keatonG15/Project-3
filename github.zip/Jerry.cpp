#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include "Jerry.h"
#include "P7.h"
using namespace std;

Jerry::Jerry(){
    
    string jerryNames[3] = {"J1", "J2", "J3"};
    for(int i = 0; i < 3; i++){
        jNames.push_back(jerryNames[i]);
    }
    srand(time(NULL));

    randNumber1 = rand()%6+1;
    randNumber2 = rand()%6+1;
    poleLevel = 1;
    mountainNumber = 1;
    swag = 0;
}
Jerry::Jerry(vector<string>name, int pL, int r1, int r2, int mountNum, int swagNum){
    for(int i = 0; i < name.size(); i++){
        jNames.push_back(name.at(i));
    }
    for(int x = name.size(); x < jNames.size(); x++){
        jNames.push_back("Jerry");
    }
    poleLevel = pL;
    randNumber1 = r1;
    randNumber2 = r2;
    mountainNumber = mountNum;
    swag = swagNum;
}
int Jerry::displayJerry(){
    srand(time(NULL));
    int userInput;
    cout << "You ran into " << getJerryName(rand()%3) << ". Do you want to:\n1.Fight\n2.Forfeit" << endl;
    cin>>userInput;
    if(userInput == 1){
        cout << "Fight Results: " << endl;
      //  cout << "R1: " <<randNumber1 << " R2: "<< randNumber2<<endl;
        setFight(poleLevel, randNumber1, randNumber2, mountainNumber, swag);
        if(getResults() == true){
        
            return 0;
            //-20 ski maintenance
            //10% chance infection
            //+25 infestation
        }else{
            cout << "Win" << endl;
            return 1;
            
            //+50 beers
        }
        //-1 ski part
        //30% chance ski maintenance-=10
    }else if(userInput == 2){
        cout << "Forfeit" << endl;
        return -1;
        //setNumSkiParts = 0
    }else{
        cout << "Invalid Input" << endl;
        return 0;
    }
return 0;
}
string Jerry::getJerryName(int index){
    return jNames.at(index);
}
bool Jerry::getResults(){
    return isDefeated;
}
   void Jerry::setFight(int pL, int r1, int r2, int mountNum, int swagNum){
    
       double maxLeft = pL*r1;
       double maxRight = (r2*mountNum)*(1/(double)swagNum);
       cout << "Poles: " << pL << "\n Swag: " << swagNum << "\n Mountain: " << mountNum << endl;
    
       //need to assign parameters using info from P7 class...
      if(maxLeft > maxRight){
        isDefeated = false;
        }else{
        isDefeated = true;
        }
   } // where we put equation for if you won or not

   int Jerry::getMountain(){
       return mountainNumber;
   }
   void Jerry::setMountain(int value){
       if(value == 0){
    mountainNumber = 1;
    }else if(value==.1){
        mountainNumber = 2;
    }else if(value ==.2){
      mountainNumber = 3;
    }else if(value == .25){
        mountainNumber = 4;
    }else if(value == .3){
        mountainNumber = 5;
    }else{
        mountainNumber = value;
    }

       // //mountainNumber = value;
   }

  int Jerry::getSwagNum(){
      return swag;
  }
   void Jerry::setSwagNum(int num){
       swag = num;
   }

   int Jerry::getPoleLvl(){ 
       return poleLevel;
   }
   void Jerry::setPoleLvl(int lvl){
       poleLevel = lvl;
   }