// CSCI 1300 Fall 2021
// Authors: Alex Norby and Keaton Glassman
// Recitation 212 and 213
// Project 3 -- P7.h


// Powder 7 Class
// Int indexOfSkiEquipment
// vector<int>numOfSkiEquipment
// Int numJBG
// Int swag
// Int poleLvl
// Bool isBroken
// Bool hasBeers
// Double rateOfMountain

#include <iostream>
#include <vector>
#include <string>
using namespace std;
 #ifndef P7_H //Helps call a class
 #define P7_H // Defines the class
 
class Jerry;
 class P7{
     public:
    P7();//default, sets everything to mountain 1 standards
    P7(int index, vector<int>numEquipment, int JBG, int numSwag, int pole, int broken, int beers, double rate);//same as default but with specific values
    
    void displayMenu();//displays menu
    void displayEquipment();//displays equipment to buy
    void displayInventory();//displays user inventory
    
    int getNumSkiEquipment(int index);//gets number of an equipment at specific index
    void setNumSkiEquipment(int index, int value);//sets number of ski equipment to specific value
    void subtractNumSkiEquipment(int index, int value);//subtracts from users equipment
    
    string getEquipment(int index);//gets the name of the equipment at an index

    double getPrice(int index);//gets price of a specific equipment
    void setPrices(double rate);//sets prices depending on mountain number

    int getNumJBG();//gets num Jerry Be Gone
    void setNumJBG(int input);//sets num Jerry Be Gone

    int getSwag();//gets swag
    void setSwag(int input);//setsSwag 

    int getPoleLvl();//gets Pole lvl
    void setPoleLvl(int input);//sets pole lvl

    int getSkis();//gets number of skis
    void setSkis(int value);//sets number of skis 

    int getBeers();//gets number or beer
    void setBeers(int value);//sets number of beers

    double getRateOfMountain();//gets rate for the menu
    void setRateOfMountain(double value);//sets rate for the menu 

    int getJerriesDefeated();//getd jerries defeated
    void setJerriesDefeated(int val);//sets jerries defeated

    void repairSki();//Ski bench to repair maintenance
    void repairVirus();//use a can of JBG
    void repairFrustration();//watch ski movies
    void setInfest(int value);//sets infestation
    void setViruses(int value);//sets number of viruses
    void setMaintenance(int value);//sets ski maintenance

    void misfortune(int mis, int main);//runs a misfortune 

//these all transfer stats back to test driver so user object can talk to hold object in different classes
    int transferFrustration();
    int transferInfestation();
    int transferVirus();
    int transferMaintenance();

//all must be publicly accessed by different classes
int poleLvl;
int swag;
double rateOfMountain;
int numSkis;
vector<int>numOfSkiEquipment;
vector<double>prices;
int numJBG;
int beers;

//private to P7
private: 
int indexOfSkiEquipment;
vector<string>equipment;


     
 };
 #endif
