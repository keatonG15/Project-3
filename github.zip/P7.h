// Powder 7 Class
// Int indexOfSkiEquipment
// vector<int>numOfSkiEquipment
// Int numJBG
// Int swag
// Int poleLvl
// Bool isBroken
// Bool hasBeers
// Double rateOfMountain

#include <iostream>
#include <vector>
#include <string>
using namespace std;
 #ifndef P7_H //Helps call a class
 #define P7_H // Defines the class
 
class Jerry;
 class P7{
     public:
    P7();
    P7(int index, vector<int>numEquipment, int JBG, int numSwag, int pole, int broken, int beers, double rate);
    
    void displayMenu();
    void displayEquipment();
    void displayInventory();
    
    int getNumSkiEquipment(int index);
    void setNumSkiEquipment(int index, int value);
    void subtractNumSkiEquipment(int index, int value);
    
    string getEquipment(int index);

    double getPrice(int index);
    void setPrices(double rate);

    int getNumJBG();
    void setNumJBG(int input);

    int getSwag();
    void setSwag(int input);

    int getPoleLvl();
    void setPoleLvl(int input);

    int getSkis();
    void setSkis(int value);

    int getBeers();
    void setBeers(int value);

    double getRateOfMountain();
    void setRateOfMountain(double value);

    int getJerriesDefeated();
    void setJerriesDefeated(int val);

    void repairSki();
    void repairVirus();
    void repairFrustration();
    void setInfest(int value);

    void misfortune(int mis, int main);


    int transferFrustration();
    int transferInfestation();
    int transferVirus();
    int transferMaintenance();

int poleLvl;
int swag;
double rateOfMountain;
int numSkis;
vector<int>numOfSkiEquipment;
vector<double>prices;
int numJBG;
int beers;


private: 
int indexOfSkiEquipment;
vector<string>equipment;


     
 };
 #endif
