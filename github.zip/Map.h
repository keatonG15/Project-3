#ifndef MAP_H
#define MAP_H

#include <fstream>
#include <iostream>
#include <ctype.h>

using namespace std; 

class Map
{
     private:
          static const int num_rows = 5;
          static const int num_cols = 9;
          static const int num_npcs = 3;
          static const int num_hackers = 6;

          int playerPosition[2];
          int p7Location[2];
          int npcPositions[num_npcs][2];
          int jerryPositions[num_hackers][3];
          char mapData[num_rows][num_cols];

          int npc_count;
          int jerry_count;
          bool p7_on_map;

     public :
          Map();

          void resetMap();

          // getters
          int getPlayerRowPosition();
          int getPlayerColPosition();
          int getNPCCount();
          int getJerryCount();

          // setters
          void setPlayerRowPosition(int);
          void setPlayerColPosition(int);
          void setNPCCount(int);
          void setJerryCount(int);

          bool spawnNPC(int, int);
          bool spawnP7(int, int);
          bool spawnJerry(int, int);

          void displayMap();
          void displayMoves();  
          bool executeMove(char);

          bool isP7Location();
          bool isNPCLocation();
          bool isJerryLocation();

          bool isP7OnMap();
          void transition();
          void winGame();
};
 
#endif